KORA SERVICES WEBSITE

1. Open index.html in a browser to preview the site.
2. Replace YOUR_KORA_PAY_LINK_HERE in index.html with your actual Kora Pay payment/checkout link.
3. The support number is +233 547 712 495.
4. Prices are displayed in Ghana cedis (GH₵).
